# complexdid

R package for treatment-effect estimation in complex designs under parallel-trends assumptions.

Based on the methodology described in *"Treatment-Effect Estimation in Complex Designs under a Parallel-trends Assumption"* by Clément de Chaisemartin and Xavier D'Haultfoeuille.

## Installation

You can install the package from source:

```r
# Install from local directory
install.packages("path/to/complexdid", repos = NULL, type = "source")

# Or using devtools
devtools::install_local("path/to/complexdid")
```

## Features

The package provides three model specifications:

1. **Base Model** (`model = "base"`): Standard RC model with K lags
2. **Full Dynamics** (`model = "full_dynamics"`): Uses all available periods
3. **Interactions** (`model = "interactions"`): Includes interaction terms between lags

## Quick Start

### Generate Synthetic Data

```r
library(complexdid)

# Generate example panel data
data <- generate_did_data(
  n_groups = 50,
  n_periods = 5,
  treatment_prob = 0.3,
  seed = 123
)

head(data)
```

### Estimate Models

#### Using the Unified Interface

```r
# Base model
result <- estim_RC_model_unified(
  K = 2,
  data = data,
  group_col = "group",
  deltaY_col = "delta_Y",
  deltaD_col = "delta_D",
  D_col = "D",
  X_cols = c("X1", "X2"),
  model = "base"
)

# View results
summary_RC_model(result)
```

#### Direct Model Functions

```r
# Base model
result_base <- estim_RC_model_base(
  K = 2,
  data = data,
  group_col = "group",
  deltaY_col = "delta_Y",
  deltaD_col = "delta_D",
  D_col = "D",
  X_cols = c("X1", "X2")
)

# Full dynamics model
result_full <- estim_RC_model_full(
  K = NULL,
  data = data,
  group_col = "group",
  deltaY_col = "delta_Y",
  deltaD_col = "delta_D",
  D_col = "D",
  X_cols = c("X1", "X2")
)

# Interactions model
result_int <- estim_RC_model_interactions(
  K = 2,
  data = data,
  group_col = "group",
  deltaY_col = "delta_Y",
  deltaD_col = "delta_D",
  D_col = "D",
  X_cols = c("X1", "X2")
)
```

### Using Custom Weights (e.g., for Bootstrap)

```r
# Count groups
n_groups <- length(unique(data$group))

# Create bootstrap weights
list_groups_boot <- sample(unique(data$group), n_groups, replace = TRUE)
weights <- as.numeric(table(factor(list_groups_boot, levels = unique(data$group))))

# Estimate with weights
result_weighted <- estim_RC_model_base(
  K = 2,
  data = data,
  group_col = "group",
  deltaY_col = "delta_Y",
  deltaD_col = "delta_D",
  D_col = "D",
  X_cols = c("X1", "X2"),
  weights = weights
)
```

## Data Format

Your data should be in long format with the following columns:

- **group identifier**: Column identifying groups (e.g., counties, individuals)
- **D**: Treatment level
- **delta_D**: First difference of treatment (ΔD)
- **Y**: Outcome variable
- **delta_Y**: First difference of outcome (ΔY)
- **X1, X2, ...**: Covariates

The first differences should exclude the first period (which would have NA values).

## Functions

### Main Estimation Functions

- `estim_RC_model_unified()`: Unified interface for all models
- `estim_RC_model_base()`: Base RC model with K lags
- `estim_RC_model_full()`: Full dynamics model
- `estim_RC_model_interactions()`: Model with interaction terms

### Utility Functions

- `generate_did_data()`: Generate synthetic panel data for testing
- `summary_RC_model()`: Print formatted summary of results

## Output Structure

All estimation functions return a list with:

- `gamma`: Coefficients for covariates
- `B_hat`: Treatment effect coefficients (betas)
- `Nobs`: Number of observations used for each coefficient
- `model`: Model type ("base", "full_dynamics", or "interactions")


## Dependencies

- R (>= 3.5.0)
- MASS

## License

MIT License - see LICENSE file for details

## Authors

- Clément de Chaisemartin
- Xavier D'Haultfoeuille
- Henri Fabre (package maintainer)

## Citation

If you use this package in your research, please cite:

```
de Chaisemartin, Clément and d'Haultfoeuille, Xavier, Treatment-Effect Estimation in Complex Designs under a Parallel-trends Assumption (September 04, 2025). Available at SSRN: https://ssrn.com/abstract=5440734 or http://dx.doi.org/10.2139/ssrn.5440734
```

## Support

For issues and questions:
- Open an issue on GitHub
- Contact the package maintainer : mailto:henri.fabre@ensae.fr

## References

de Chaisemartin, Clément and d'Haultfoeuille, Xavier, Treatment-Effect Estimation in Complex Designs under a Parallel-trends Assumption (September 04, 2025). Available at SSRN: https://ssrn.com/abstract=5440734 or http://dx.doi.org/10.2139/ssrn.5440734

library(testthat)
library(complexdid)

test_check("complexdid")
